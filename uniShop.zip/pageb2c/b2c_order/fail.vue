<template>
	<view>
		<view class="emptyData">支付失败</view>
	</view>
</template>

<script>
</script>

<style>
</style>
