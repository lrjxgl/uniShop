<template>
	<view >
		<checkbox-group>
			<label v-for="(item,index) in checkList" :key="index">
				<checkbox name="aa[]" @click="setCheck(item.value)" :checked="item.checked" :value="item.value"  />{{item.label}}
			</label>
			 
		</checkbox-group> 
		 
	</view>
</template>

<script>
	var num=0;
	export default{
		data:function(){
			return {
				title:"我是标题",
				content:"我是内容",
				nickname:"这是昵称",
				list:[],
				cls:"cl-red",
				style:"font-size:36px;color:f30;",
				num:2,
				baseList:[],
				checkList:[
					{
						"label":"A",
						"value":"a",
						"checked":true
					},
					{
						"label":"B",
						"value":"b",
						"checked":false
					},
					{
						"label":"C",
						"value":"c",
						"checked":false
					},
					{
						"label":"D",
						"value":"d",
						"checked":false
					},
				],
			}
		},
		onLoad:function(ops){
			//this.baseList=this.checkList;
			this.getPage();
		},
		onReachBottom:function(){
			this.getList();
		},
		onPullDownRefresh:function(){
			this.getPage();
			uni.stopPullDownRefresh();
		},
		 
		methods:{
			setCheck:function(val){
				
				 
			},
			clickMe:function(msg){
				 
				
			},
			getPage:async  function(){
				var that=this;
				var [error, success] =await that.app.getSync({
					url:that.app.apiHost+"/module.php?m=b2c&ajax=1"
				})
				var res=success.data;
				console.log(res.data); 
				var id=res.data.recList[0].id;
				var [error, success] =await that.app.postSync({
					url:that.app.apiHost+"/module.php?m=b2c_product&a=show&ajax=1",
					data:{
						id:id
					}
				})
				 
				var res=success.data;
				console.log(res.data);
				 
			},
			getList:function(){
				var list=this.list;
				for(var i=0;i<50;i++){
					num++;
					list.push('这是第'+num+'条新闻');
				}
				this.list=list;
			}
		}
	}
</script>

<style>
</style>
