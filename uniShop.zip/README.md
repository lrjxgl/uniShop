# uniShop
* 得推uniShop商城支持正常销售、拼团、限时促销模式
* 得推B2C商城系统，php后端针对uniApp开发者授权优惠促销价，只要1000元。
* 得推云微站可以申请直接开通B2C商城，不用自建网站。
* 官网 http://www.deituicms.com
# 安装说明
* http://uniapp.dcloud.io/ 
* 下载HBuilderX 
* 用HBuilderX打开目录或者直接从git新建项目 

# 技术支持
* QQ：362606856
* 微信/电话：15985840591
* 案例：微信“福鼎口福白茶”

